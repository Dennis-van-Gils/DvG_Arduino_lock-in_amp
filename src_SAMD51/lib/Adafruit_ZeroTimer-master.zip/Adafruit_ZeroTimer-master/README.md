# Adafruit_ZeroTimer
simple wrappers for TC modules 3,4,5 on SAMD21 and SAMD51

## This code is not for public consumption!
we use this library internally for some things, and published it but it is not supported, or documented or guaranteed to work whatsoever!
