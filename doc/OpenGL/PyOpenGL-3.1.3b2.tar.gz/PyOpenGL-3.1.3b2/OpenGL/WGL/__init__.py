from OpenGL.raw.WGL.VERSION.WGL_1_0 import *

wglUseFontBitmaps = wglUseFontBitmapsW
