# Avdweb_SAMDtimer
SAMD21 Timer library for the SAM15x15 and Arduino Zero
http://www.avdweb.nl/arduino/libraries/samd21-timer.html

Attention: The new libraries Adafruit_ASFcore and Adafruit_ZeroTimer don't work anymore with the avdweb_SAMDtimer library.
Therefore, install the older libraries, see the zip files.
