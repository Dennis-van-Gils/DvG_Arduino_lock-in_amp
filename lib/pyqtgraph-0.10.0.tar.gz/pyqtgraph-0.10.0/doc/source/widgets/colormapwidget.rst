ColorMapWidget
==============

.. autoclass:: pyqtgraph.ColorMapWidget
    :members:

    .. automethod:: pyqtgraph.ColorMapWidget.__init__

    .. automethod:: pyqtgraph.widgets.ColorMapWidget.ColorMapParameter.setFields

    .. automethod:: pyqtgraph.widgets.ColorMapWidget.ColorMapParameter.map
    