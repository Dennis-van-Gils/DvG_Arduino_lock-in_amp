SpinBox
=======

.. autoclass:: pyqtgraph.SpinBox
    :members:

    .. automethod:: pyqtgraph.SpinBox.__init__

