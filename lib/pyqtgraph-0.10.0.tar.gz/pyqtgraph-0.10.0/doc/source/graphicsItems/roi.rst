ROI
===

.. autoclass:: pyqtgraph.ROI
    :members:

.. autoclass:: pyqtgraph.RectROI
    :members:

.. autoclass:: pyqtgraph.EllipseROI
    :members:

.. autoclass:: pyqtgraph.CircleROI
    :members:

.. autoclass:: pyqtgraph.LineSegmentROI
    :members:

.. autoclass:: pyqtgraph.PolyLineROI
    :members:

.. autoclass:: pyqtgraph.LineROI
    :members:

.. autoclass:: pyqtgraph.MultiRectROI
    :members:


