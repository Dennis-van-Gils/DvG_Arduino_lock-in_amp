UIGraphicsItem
==============

.. autoclass:: pyqtgraph.UIGraphicsItem
    :members:

    .. automethod:: pyqtgraph.UIGraphicsItem.__init__

