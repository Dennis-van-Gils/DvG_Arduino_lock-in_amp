GLGridItem
==========

.. autoclass:: pyqtgraph.opengl.GLGridItem
    :members:

    .. automethod:: pyqtgraph.opengl.GLGridItem.__init__

