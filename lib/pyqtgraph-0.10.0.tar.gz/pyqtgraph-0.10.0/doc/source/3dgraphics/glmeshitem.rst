GLMeshItem
==========

.. autoclass:: pyqtgraph.opengl.GLMeshItem
    :members:

    .. automethod:: pyqtgraph.opengl.GLMeshItem.__init__

